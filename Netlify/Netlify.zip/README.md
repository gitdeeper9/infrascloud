# ⚡ INFRAS-CLOUD Netlify Dashboard

**Atmospheric Infrasound & Severe Weather Acoustic Signatures**

[![Netlify Status](https://api.netlify.com/api/v1/badges/infrascloud/deploy-status)](https://infrascloud.netlify.app)
[![DOI](https://img.shields.io/badge/DOI-10.5281%2Fzenodo.18952438-orange)](https://doi.org/10.5281/zenodo.18952438)
[![Python](https://img.shields.io/badge/Python-3.10%2B-blue)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green)](LICENSE)

---

## 🚀 Live Dashboard
- **Dashboard:** [https://infrascloud.netlify.app](https://infrascloud.netlify.app)
- **API:** [https://infrascloud.netlify.app/api](https://infrascloud.netlify.app/api)
- **Reports:** [https://infrascloud.netlify.app/reports](https://infrascloud.netlify.app/reports)
- **Documentation:** [https://infrascloud.netlify.app/docs](https://infrascloud.netlify.app/docs)

## 📡 API Endpoints

| Endpoint | Description | Parameters |
|----------|-------------|------------|
| `/api/aisi` | Current AISI values for all stations | - |
| `/api/station/:id` | Station-specific data | `id` (station code) |
| `/api/parameters` | Eight parameters data | `limit` (default: 10) |
| `/api/alerts` | Active severe weather alerts | - |
| `/api/stats` | System statistics | - |
| `/api/history` | Historical AISI data | `station`, `days` |

### Example API Call
```bash
# Get AISI data for all stations
curl https://infrascloud.netlify.app/api/aisi

# Get history for IS42 station
curl https://infrascloud.netlify.app/api/history?station=IS42&days=30
```

📊 Key Metrics

Metric Value
AISI Classification Accuracy 93.1%
Cyclone Detection Range 4,200 km
Tornado Precursor Lead Time 12–28 min
Validated Events 1,847
IMS Stations 47
False Detection Rate 3.2%

🔧 Local Development

```bash
# Clone repository
git clone https://gitlab.com/gitdeeper9/infrascloud.git
cd infrascloud/netlify

# Install Netlify CLI
npm install -g netlify-cli

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your Supabase credentials

# Start local server
netlify dev
```

🏗️ Project Structure

```
netlify/
├── public/                 # Static files
│   ├── index.html         # Main dashboard
│   ├── dashboard.html      # Live AISI dashboard
│   └── reports.html        # Reports archive
├── functions/              # Netlify Functions
│   ├── aisi.js            # AISI data endpoint
│   ├── station.js          # Station-specific data
│   ├── parameters.js       # Eight parameters data
│   ├── alerts.js          # Weather alerts
│   ├── stats.js           # System statistics
│   └── history.js         # Historical data
├── package.json           # Dependencies
├── netlify.toml           # Netlify configuration
└── .env.example           # Environment variables template
```

🗄️ Database Schema (Supabase)

```sql
-- Stations table
CREATE TABLE infrascloud_stations (
  station_id SERIAL PRIMARY KEY,
  station_code VARCHAR(10) UNIQUE NOT NULL,
  station_name VARCHAR(100),
  network VARCHAR(50) DEFAULT 'IMS',
  latitude DECIMAL(10,8),
  longitude DECIMAL(11,8),
  country VARCHAR(100)
);

-- Parameters table (eight parameters)
CREATE TABLE infrascloud_parameters (
  param_id SERIAL PRIMARY KEY,
  station_id INTEGER REFERENCES infrascloud_stations(station_id),
  timestamp TIMESTAMPTZ DEFAULT NOW(),
  aisi_value DECIMAL(4,3),
  aisi_status VARCHAR(20),
  p_ub_value DECIMAL(6,4),
  d_str_value DECIMAL(5,3),
  f_p_value DECIMAL(5,3),
  theta_value DECIMAL(6,2),
  v_ph_value DECIMAL(6,2),
  alpha_air_value DECIMAL(7,5),
  gamma2_value DECIMAL(4,3),
  snr_value DECIMAL(5,2)
);

-- Alerts table
CREATE TABLE infrascloud_alerts (
  alert_id SERIAL PRIMARY KEY,
  station_id INTEGER REFERENCES infrascloud_stations(station_id),
  alert_timestamp TIMESTAMPTZ DEFAULT NOW(),
  alert_type VARCHAR(20),
  alert_level VARCHAR(20),
  aisi_value DECIMAL(4,3),
  message TEXT,
  resolved BOOLEAN DEFAULT FALSE
);
```

📖 Citation

If you use INFRAS-CLOUD in your research, please cite:

```bibtex
@software{baladi2026infrascloud,
  author = {Baladi, Samir},
  title = {INFRAS-CLOUD: Atmospheric Infrasound \& Severe Weather Acoustic Signatures},
  year = {2026},
  version = {1.0.0},
  doi = {10.5281/zenodo.18952438},
  url = {https://gitlab.com/gitdeeper9/infrascloud}
}
```

📬 Contact

· Author: Samir Baladi
· Email: gitdeeper@gmail.com
· ORCID: 0009-0003-8903-0029
· GitLab: gitlab.com/gitdeeper9/infrascloud
· DOI: 10.5281/zenodo.18952438

---

⚡ INFRAS-CLOUD — The atmosphere has always been speaking. Now we can listen.
