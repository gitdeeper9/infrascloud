const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    // جلب المحطات
    const { data: stations, error: stationsError } = await supabase
      .from('infrascloud_stations')
      .select('*');

    if (stationsError) throw stationsError;

    // جلب آخر قياس لكل محطة
    const { data: params, error: paramsError } = await supabase
      .from('infrascloud_parameters')
      .select('*')
      .order('timestamp', { ascending: false });

    if (paramsError) throw paramsError;

    // إنشاء خريطة لأحدث قياس لكل محطة
    const latestParams = {};
    params.forEach(p => {
      if (!latestParams[p.station_id] || p.timestamp > latestParams[p.station_id].timestamp) {
        latestParams[p.station_id] = p;
      }
    });

    const stationsData = stations.map(station => {
      const param = latestParams[station.station_id] || {};
      return {
        id: station.station_code,
        name: station.station_name,
        country: station.country,
        network: station.network,
        lat: station.latitude,
        lon: station.longitude,
        aisi: param.aisi_value || 0.5,
        alert: param.aisi_status || 'BACKGROUND',
        p_ub: param.p_ub_value,
        d_str: param.d_str_value,
        f_p: param.f_p_value,
        theta: param.theta_value,
        v_ph: param.v_ph_value,
        alpha_air: param.alpha_air_value,
        gamma2: param.gamma2_value,
        snr: param.snr_value
      };
    });

    const aisiValues = stationsData.map(s => s.aisi);
    const avgAisi = aisiValues.reduce((a, b) => a + b, 0) / aisiValues.length;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        stations: stationsData,
        statistics: {
          global_avg_aisi: Number(avgAisi.toFixed(3)),
          global_status: avgAisi >= 0.8 ? 'CRITICAL' : avgAisi >= 0.55 ? 'ELEVATED' : 'BACKGROUND',
          stations_count: stationsData.length
        }
      })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
