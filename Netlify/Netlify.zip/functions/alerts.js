const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const { data: active, error: activeError } = await supabase
      .from('infrascloud_alerts')
      .select(`
        *,
        infrascloud_stations!inner(station_code, station_name)
      `)
      .eq('resolved', false)
      .order('alert_timestamp', { ascending: false });

    if (activeError) throw activeError;

    const { data: recent, error: recentError } = await supabase
      .from('infrascloud_alerts')
      .select(`
        *,
        infrascloud_stations!inner(station_code, station_name)
      `)
      .eq('resolved', true)
      .order('alert_timestamp', { ascending: false })
      .limit(10);

    if (recentError) throw recentError;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ 
        active: active || [], 
        recent: recent || [],
        active_count: active?.length || 0
      })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
