const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    // جلب آخر 10 قياسات
    const { data: measurements, error } = await supabase
      .from('infrascloud_parameters')
      .select('*')
      .order('timestamp', { ascending: false })
      .limit(10);

    if (error) throw error;

    // جلب أسماء المحطات
    const { data: stations } = await supabase
      .from('infrascloud_stations')
      .select('station_id, station_code, station_name');

    // دمج البيانات
    const enhancedMeasurements = measurements.map(m => {
      const station = stations?.find(s => s.station_id === m.station_id) || {};
      return {
        ...m,
        infrascloud_stations: {
          station_code: station.station_code,
          station_name: station.station_name
        }
      };
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        latest_measurements: enhancedMeasurements || []
      })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
