const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const stationCode = event.queryStringParameters?.id || 'IS42';

    const { data: station, error: stationError } = await supabase
      .from('infrascloud_stations')
      .select('*')
      .eq('station_code', stationCode)
      .single();

    if (stationError) throw stationError;

    const { data: params, error: paramsError } = await supabase
      .from('infrascloud_parameters')
      .select('*')
      .eq('station_id', station.station_id)
      .order('timestamp', { ascending: false })
      .limit(30);

    if (paramsError) throw paramsError;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ 
        station, 
        measurements: params || [] 
      })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
