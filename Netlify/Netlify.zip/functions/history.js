const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const stationCode = event.queryStringParameters?.station || 'IS42';
    const days = parseInt(event.queryStringParameters?.days) || 30;

    const { data: station, error: stationError } = await supabase
      .from('infrascloud_stations')
      .select('station_id')
      .eq('station_code', stationCode)
      .single();

    if (stationError) throw stationError;

    const { data: history, error: historyError } = await supabase
      .from('infrascloud_parameters')
      .select('timestamp, aisi_value, p_ub_value, d_str_value, f_p_value, theta_value, v_ph_value, alpha_air_value, gamma2_value, snr_value')
      .eq('station_id', station.station_id)
      .order('timestamp', { ascending: false })
      .limit(days);

    if (historyError) throw historyError;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ 
        station: stationCode, 
        history: history || [] 
      })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
